package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.icu.text.DisplayContext;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;

import java.time.DateTimeException;

public class MainActivity extends AppCompatActivity {
    private Button button;
    TextView result;
    EditText StartTime, EndTime;
    Button Bereken;

    int ResultNum;
    int num1,num2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button=(Button) findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                OpenCalculator();
            }
        });
        result=(TextView) findViewById(R.id.txtUur);
        StartTime=(EditText) findViewById(R.id.StartTime);
        EndTime=(EditText) findViewById(R.id.EndTime);
        Bereken=(Button) findViewById(R.id.btnCalc);

        Bereken.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                num1=Integer.parseInt(StartTime.getText().toString());
                num2=Integer.parseInt(EndTime.getText().toString());
                if(num1>24||num2>24){
                    result.setText("max waarde is 24");
                }
                else if(num2>num1){

                    ResultNum=num2-num1;
                    result.setText(String.valueOf(ResultNum)+" uur");
                }
                else if(num2<num1){
                    result.setText("Eindwaarde kan niet kleiner zijn dan startwaarde!");
                }
                else if(num2==num1){
                    result.setText("0 uur");
                }


            }
        });
    }
    public void OpenCalculator(){
        Intent intent= new Intent(this, Calculator.class);
        startActivity(intent);
    }


}